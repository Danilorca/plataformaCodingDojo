function turnOff(element){
  element.innerText = "Logout";
}


function hide(element){
  element.remove();
}


function alertar(texto) {
   alert(texto);
}