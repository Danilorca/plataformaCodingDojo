let videoWeb= document.getElementById("video")

function playVideo (){
  videoWeb.play();
}

function stopVideo() {
  videoWeb.pause();
}